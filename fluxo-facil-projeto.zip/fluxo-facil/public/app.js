(function(){
'use strict';
var MES=['jan','fev','mar','abr','mai','jun','jul','ago','set','out','nov','dez'];
var MESL=['janeiro','fevereiro','março','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro'];
var $=function(s,r){return (r||document).querySelector(s)};
var esc=function(s){return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})};
var pad=function(n){return String(n).padStart(2,'0')};
var ymd=function(d){return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())};
var NOW=new Date(), TODAY=ymd(NOW);
var CUR={y:NOW.getFullYear(),m:NOW.getMonth()+1}, CURKEY=CUR.y*100+CUR.m;
var parseD=function(s){var p=s.split('-').map(Number);return {y:p[0],m:p[1],d:p[2]}};
var mkey=function(s){var p=parseD(s);return p.y*100+p.m};
var addMonths=function(y,m,n){var t=y*12+(m-1)+n;return {y:Math.floor(t/12),m:t%12+1}};
var uid=function(){return Math.random().toString(36).slice(2,9)+Date.now().toString(36).slice(-3)};
var ic=function(n,c){return '<svg class="ic '+(c||'')+'" aria-hidden="true"><use href="#i-'+n+'"/></svg>'};
var round2=function(x){return Math.round(x*100)/100};

/* ---------- dinheiro ---------- */
var BRL=new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'});
var HIDE='R$ •••••';
var S;
function m(v){return S.prefs.hide?HIDE:BRL.format(round2(v)).replace(/ /g,' ')}
function kfmt(v){if(S.prefs.hide)return '•••';var a=Math.abs(v),s=v<0?'-':'';return a>=1000?s+(a/1000).toFixed(1).replace('.',',')+' mil':s+Math.round(a)}
function parseMoney(s){s=String(s).replace(/[^\d.,-]/g,'');var neg=s.charAt(0)==='-';s=s.replace(/-/g,'');if(!s)return 0;
  if(s.indexOf(',')>=0){s=s.replace(/\./g,'').replace(',','.')}
  else{var p=s.split('.');if(p.length>2||(p.length===2&&p[1].length===3))s=s.replace(/\./g,'')}
  var n=parseFloat(s);return isNaN(n)?0:(neg?-n:n)}
function relDate(s){
  if(s===TODAY)return 'hoje';
  var a=new Date(s+'T12:00:00'),b=new Date(TODAY+'T12:00:00'),d=Math.round((a-b)/864e5);
  if(d===1)return 'amanhã';if(d===-1)return 'ontem';
  var p=parseD(s);return 'dia '+p.d+' de '+MES[p.m-1]}
function monthName(k){var y=Math.floor(k/100),mm=k%100;return MESL[mm-1]+' de '+y}

/* ---------- dados de exemplo (baseados no plano de contas da planilha) ---------- */
var DEFAULT_CATS=[
 {id:'e1',nome:'Vendas no PIX',tipo:'E'},{id:'e2',nome:'Vendas no cartão',tipo:'E'},{id:'e3',nome:'Vendas em dinheiro',tipo:'E'},{id:'e4',nome:'Serviços prestados',tipo:'E'},
 {id:'s1',nome:'Aluguel',tipo:'S'},{id:'s2',nome:'Fornecedores',tipo:'S'},{id:'s3',nome:'Funcionários',tipo:'S'},{id:'s4',nome:'Impostos',tipo:'S'},
 {id:'s5',nome:'Contador',tipo:'S'},{id:'s6',nome:'Luz, água e internet',tipo:'S'},{id:'s7',nome:'Taxas do banco',tipo:'S'},{id:'s8',nome:'Retirada do sócio',tipo:'S'}];
function rnd(n){var x=Math.sin(n*9301+49297)*233280;return x-Math.floor(x)}
function seed(){
  var L=[],k=0;
  function add(c,date,v,obs,pago){L.push({id:'x'+(k++),date:date,cat:c,valor:Math.round(v),pago:pago===undefined?date<=TODAY:pago,obs:obs||''})}
  for(var off=-5;off<=6;off++){
    var mm=addMonths(CUR.y,CUR.m,off),dim=new Date(mm.y,mm.m,0).getDate();
    var D=function(d){return mm.y+'-'+pad(mm.m)+'-'+pad(Math.min(d,dim))};
    var f=off>0?0.93:1,j=function(i,a){return (rnd(off*10+i)-.5)*2*a};
    add('e1',D(5),(3900+j(1,300))*f);add('e2',D(12),(3300+j(2,300))*f);add('e3',D(20),(1100+j(3,150))*f);add('e4',D(25),(1300+j(4,200))*f);
    add('s1',D(5),2200);add('s2',D(10),2500*Math.pow(1.02,off+5)+j(5,60));add('s3',D(7),2200);add('s4',D(20),700);
    add('s5',D(15),350);add('s6',D(18),420+j(6,25));add('s7',D(22),190);add('s8',D(28),1000);
  }
  var od=new Date(NOW);od.setDate(od.getDate()-12);
  add('e4',ymd(od),1800,'Cliente Marina ainda não pagou',false);
  return L}
function fresh(example){
  return {v:1,empresa:example?'Loja Exemplo':'Minha empresa',saldoInicial:example?6000:0,
    cats:DEFAULT_CATS.map(function(c){return Object.assign({},c)}),lanc:example?seed():[],
    prefs:{size:1,hc:false,hide:false},exemplo:!!example}}
/* ---------- conta, servidor e preferências ---------- */
var PREFKEY='fluxo-facil-prefs';
function loadPrefs(){try{var p=JSON.parse(localStorage.getItem(PREFKEY));if(p&&typeof p==='object')return {size:[1,2,3].indexOf(p.size)>=0?p.size:1,hc:p.hc===true,hide:false}}catch(e){}return {size:1,hc:false,hide:false}}
var LP=loadPrefs();
var P=function(){return S?S.prefs:LP};
var saveT=null;
function api(method,url,body){
  var o={method:method,credentials:'same-origin',headers:{'X-Requested-With':'fluxo-facil'}};
  if(body!==undefined){o.headers['Content-Type']='application/json';o.body=JSON.stringify(body)}
  return fetch(url,o).then(function(r){return r.json().catch(function(){return {}}).then(function(d){return {ok:r.ok,status:r.status,data:d||{}}})})
    .catch(function(){return {ok:false,status:0,data:{message:'Sem conexão com a internet. Confira e tente de novo.'}}});
}
function save(){
  try{localStorage.setItem(PREFKEY,JSON.stringify({size:P().size,hc:P().hc}))}catch(e){}
  if(S&&ui.user){clearTimeout(saveT);saveT=setTimeout(flush,600)}
}
function flush(){
  if(!S||!ui.user)return Promise.resolve();
  clearTimeout(saveT);saveT=null;
  return api('PUT','/api/dados',{dados:S}).then(function(r){
    if(r.status===401)sessionEnded('Sua sessão terminou. Entre de novo para continuar.');
    else if(!r.ok)toast('Não consegui salvar agora. Confira a internet.');
  });
}
function normState(d){
  d=d&&typeof d==='object'?d:{};var o=fresh(false);
  if(Array.isArray(d.cats))o.cats=d.cats;if(Array.isArray(d.lanc))o.lanc=d.lanc;
  if(typeof d.empresa==='string')o.empresa=d.empresa;if(typeof d.saldoInicial==='number')o.saldoInicial=d.saldoInicial;
  o.exemplo=d.exemplo===true;var p=d.prefs||{};
  o.prefs={size:[1,2,3].indexOf(p.size)>=0?p.size:LP.size,hc:typeof p.hc==='boolean'?p.hc:LP.hc,hide:p.hide===true};
  return o;
}
function enter(email,avisos){
  ui.user={email:email,avisos:avisos!==false};
  return api('GET','/api/dados').then(function(r){
    if(r.status===401){sessionEnded('Sua sessão terminou. Entre de novo para continuar.');return}
    var has=r.ok&&r.data.dados;
    S=has?normState(r.data.dados):fresh(false);
    if(!has){S.prefs.size=LP.size;S.prefs.hc=LP.hc}
    ui.tab='inicio';ui.sheet=null;ui.wiz=null;document.body.style.overflow='';$('#sheet').hidden=true;
    render();window.scrollTo(0,0);
  });
}
function sessionEnded(msg,ok){
  ui.user=null;S=null;ui.sheet=null;ui.wiz=null;ui.acc={};document.body.style.overflow='';$('#sheet').hidden=true;
  ui.auth=ok?{screen:'login',msg:msg}:{screen:'login',err:msg};render();window.scrollTo(0,0);
}


/* ---------- lógica do fluxo (espelha a aba Análise da planilha) ---------- */
var cat=function(id){return S.cats.find(function(c){return c.id===id})};
var signed=function(l){var c=cat(l.cat);return c&&c.tipo==='E'?l.valor:-l.valor};
var passes=function(l,st){return st==='todos'||(st==='pago'&&l.pago)||(st==='aberto'&&!l.pago)};
function window12(start,st){
  var sk=start.y*100+start.m,open=S.saldoInicial;
  S.lanc.forEach(function(l){if(mkey(l.date)<sk&&passes(l,st)&&cat(l.cat))open+=signed(l)});
  var months=[],acc=open;
  for(var i=0;i<12;i++){
    var mm=addMonths(start.y,start.m,i),key=mm.y*100+mm.m;
    var o={key:key,y:mm.y,m:mm.m,E:0,S:0,byE:{},byS:{},n:0};
    S.lanc.forEach(function(l){
      if(mkey(l.date)!==key||!passes(l,st))return;var c=cat(l.cat);if(!c)return;o.n++;
      if(c.tipo==='E'){o.E+=l.valor;o.byE[c.id]=(o.byE[c.id]||0)+l.valor}else{o.S+=l.valor;o.byS[c.id]=(o.byS[c.id]||0)+l.valor}});
    o.E=round2(o.E);o.S=round2(o.S);o.op=round2(o.E-o.S);acc=round2(acc+o.op);o.acc=acc;months.push(o)}
  return {open:open,months:months}}
function monthSum(y,mo,st){return window12({y:y,m:mo},st).months[0]}
function balanceNow(){var b=S.saldoInicial;S.lanc.forEach(function(l){if(l.pago&&cat(l.cat))b+=signed(l)});return round2(b)}
function forecastEnd(){var b=S.saldoInicial;S.lanc.forEach(function(l){if(mkey(l.date)<=CURKEY&&cat(l.cat))b+=signed(l)});return round2(b)}

/* ---------- assistente: as 15 situações do Tutorial viram regras ---------- */
var SEV={crit:{lb:'Atenção urgente',ic:'warn',o:0},warn:{lb:'Fique atento',ic:'warn',o:1},info:{lb:'Bom saber',ic:'info',o:2},good:{lb:'Tudo bem',ic:'ok',o:3}};
function alerts(){
  var start=addMonths(CUR.y,CUR.m,-5),W=window12(start,'todos'),P=window12(start,'pago'),out=[];
  var push=function(sev,t,a,b){out.push({sev:sev,t:t,a:a,b:b})};
  if(!S.lanc.length){push('info','Comece registrando o que entra e o que sai','Ainda não há lançamentos. Sem eles, não dá para mostrar como está o seu caixa.','Toque em “Entrou dinheiro” ou “Saiu dinheiro” na tela inicial e registre o primeiro valor.');return out}
  var mc=W.months[5],past=W.months.slice(0,6).filter(function(x){return x.n>0});
  if(mc.op<0)push('warn','Este mês você gasta mais do que recebe','As saídas ('+m(mc.S)+') passam das entradas ('+m(mc.E)+') em '+MESL[CUR.m-1]+'.','Veja as despesas maiores, confira recebimentos atrasados e veja se vai precisar de dinheiro de giro.');
  else if(mc.op>0)push('good','Este mês sobra dinheiro','As entradas ('+m(mc.E)+') passam das saídas ('+m(mc.S)+') em '+MESL[CUR.m-1]+'. Sobram '+m(mc.op)+'.','Decida se a sobra vai para uma reserva, para investimento ou para pagar dívidas.');
  var neg=past.filter(function(x){return x.op<0}).length,pos=past.filter(function(x){return x.op>0}).length;
  if(neg>=3)push('warn','Vários meses terminaram no vermelho','Em '+neg+' dos últimos '+past.length+' meses você gastou mais do que recebeu.','Reveja gastos fixos, prazos de recebimento, preços e despesas do dia a dia.');
  else if(pos>=3&&neg===0)push('good','Seu caixa vem sendo saudável','Em '+pos+' meses seguidos entrou mais do que saiu.','Mantenha o controle e planeje o crescimento com segurança.');
  var last=W.months[11],delta=last.acc-W.open;
  if(delta<-Math.abs(W.open)*0.05-1)push('warn','O caixa está diminuindo ao longo dos meses','O saldo vai de '+m(W.open)+' para '+m(last.acc)+' em '+MES[last.m-1]+'/'+last.y+'.','Ache os meses mais críticos e aja antes que o dinheiro falte.');
  else if(delta>Math.abs(W.open)*0.05+1)push('good','O caixa está crescendo','O saldo vai de '+m(W.open)+' para '+m(last.acc)+' em '+MES[last.m-1]+'/'+last.y+'.','Crie uma reserva financeira e planeje investimentos.');
  var ni=W.months.findIndex(function(x){return x.acc<0});
  if(ni>=0){var x=W.months[ni];push(ni<=3?'crit':'warn','O caixa pode ficar negativo em '+MESL[x.m-1],'Pelas contas lançadas, o saldo chega a '+m(x.acc)+' em '+MES[x.m-1]+'/'+x.y+'. Pode faltar dinheiro para os compromissos.','Antecipe recebimentos, negocie prazos com fornecedores, adie gastos que dá e, se precisar, procure capital de giro antes dessa data.')}
  if(P.months[11].acc>=0&&last.acc<0)push('warn','O que já foi pago está bom, mas as pendências pioram o caixa','Só com o que já foi pago o saldo fica positivo. Com o que ainda vai acontecer, fica negativo.','Planeje os próximos pagamentos e confirme os recebimentos previstos.');
  var tE=0,tS=0,bE={},bS={};
  W.months.forEach(function(x){tE+=x.E;tS+=x.S;Object.keys(x.byE).forEach(function(k){bE[k]=(bE[k]||0)+x.byE[k]});Object.keys(x.byS).forEach(function(k){bS[k]=(bS[k]||0)+x.byS[k]})});
  var sE=Object.keys(bE).sort(function(a,b){return bE[b]-bE[a]}),sS=Object.keys(bS).sort(function(a,b){return bS[b]-bS[a]});
  if(sE.length>1&&bE[sE[0]]/tE>=.5)push('warn','Muita entrada vem de uma só fonte','“'+cat(sE[0]).nome+'” responde por '+Math.round(bE[sE[0]]/tE*100)+'% do que entra.','Procure ampliar clientes, produtos ou canais de venda.');
  if(sS.length>2&&(bS[sS[0]]+bS[sS[1]])/tS>=.45)push('info','Poucas despesas pesam muito','“'+cat(sS[0]).nome+'” e “'+cat(sS[1]).nome+'” somam '+Math.round((bS[sS[0]]+bS[sS[1]])/tS*100)+'% de tudo que sai.','Tente renegociar contratos, fornecedores e despesas fixas.');
  var oE=S.lanc.filter(function(l){return !l.pago&&l.date<TODAY&&cat(l.cat)&&cat(l.cat).tipo==='E'}),oS=S.lanc.filter(function(l){return !l.pago&&l.date<TODAY&&cat(l.cat)&&cat(l.cat).tipo==='S'});
  var sum=function(a){return a.reduce(function(s,l){return s+l.valor},0)};
  if(oE.length)push('warn','Tem dinheiro atrasado para receber','São '+oE.length+' recebimento(s) vencido(s), somando '+m(sum(oE))+'.','Cobre os clientes, reveja prazos e acompanhe de perto as contas a receber.');
  if(oS.length)push('crit','Tem conta vencida sem pagar','São '+oS.length+' conta(s) vencida(s), somando '+m(sum(oS))+'.','Priorize as obrigações críticas e combine novo prazo, se precisar.');
  var in7=new Date(NOW);in7.setDate(in7.getDate()+7);var lim=ymd(in7);
  var soon=S.lanc.filter(function(l){return !l.pago&&l.date>=TODAY&&l.date<=lim&&cat(l.cat)&&cat(l.cat).tipo==='S'});
  if(soon.length)push('info','Contas vencem nos próximos 7 dias','São '+soon.length+' conta(s), somando '+m(sum(soon))+'.','Separe o dinheiro e programe o pagamento.');
  var es=past.map(function(x){return x.E}).filter(function(v){return v>0});
  if(es.length>=3){var avg=es.reduce(function(a,b){return a+b},0)/es.length,sd=Math.sqrt(es.reduce(function(a,b){return a+(b-avg)*(b-avg)},0)/es.length);
    if(sd/avg>.35)push('info','Suas entradas variam muito de um mês para o outro','Há meses bem fortes e outros bem fracos.','Monte uma reserva para os meses mais fracos.')}
  out.sort(function(a,b){return SEV[a.sev].o-SEV[b.sev].o});
  return out}

/* ---------- estado da interface ---------- */
var ui={user:null,auth:{screen:'loading'},acc:{},tab:'inicio',status:'todos',win:addMonths(CUR.y,CUR.m,-5),sel:CURKEY,lm:{y:CUR.y,m:CUR.m},lf:'todos',sheet:null,wiz:null,conf:null,lancId:null};
var TABS=[['inicio','home','Início'],['extrato','list','Extrato'],['caixa','chart','Meu caixa'],['dicas','bulb','Dicas'],['menu','menu','Menu']];
function toast(t){var e=$('#toast');e.textContent=t;e.hidden=false;clearTimeout(toast.t);toast.t=setTimeout(function(){e.hidden=true},3200)}

/* ---------- telas ---------- */
function renderTop(){
  if(!ui.user){$('#topbar').innerHTML='<span class="logo">'+ic('coin')+'</span><div class="who"><b>Fluxo Fácil</b><span>Seu caixa, simples de entender</span></div>';return}
  $('#topbar').innerHTML='<span class="logo">'+ic('coin')+'</span><div class="who"><b>Fluxo Fácil</b><span>'+esc(S.empresa)+'</span></div>'+
  '<button class="iconbtn" data-act="hide" aria-label="'+(S.prefs.hide?'Mostrar os valores':'Esconder os valores')+'" aria-pressed="'+S.prefs.hide+'">'+ic(S.prefs.hide?'eyeoff':'eye')+'</button>'}
function renderTabs(){
  $('.tabs').hidden=!ui.user;if(!ui.user)return;
  $('#tabs').innerHTML=TABS.map(function(t){return '<button data-act="tab" data-v="'+t[0]+'"'+(ui.tab===t[0]?' aria-current="page"':'')+'>'+ic(t[1])+'<span>'+t[2]+'</span></button>'}).join('')}
function alertCard(a){var s=SEV[a.sev];return '<article class="card tip"><span class="chip '+a.sev+'">'+ic(s.ic)+s.lb+'</span><h3>'+esc(a.t)+'</h3>'+
  '<div class="blk"><b>O que significa</b>'+esc(a.a)+'</div><div class="blk"><b>O que fazer</b>'+esc(a.b)+'</div></article>'}
function lrow(l,withDate){
  var c=cat(l.cat)||{nome:'Sem categoria',tipo:'S'},e=c.tipo==='E',od=!l.pago&&l.date<TODAY;
  var st=l.pago?(e?'Recebido':'Pago'):(od?'Atrasado':(e?'A receber':'A pagar'));
  var kind=l.pago?'good':(od?'crit':'neutral');
  return '<button class="lrow" data-act="lanc" data-id="'+l.id+'"><span class="dot '+(e?'in':'out')+'">'+ic(e?'in':'out')+'</span>'+
  '<span class="tx"><b>'+esc(c.nome)+'</b><small>'+(withDate?relDate(l.date)+(l.obs?' · ':''):'')+esc(l.obs||'')+(l.rec?' · repete todo mês':'')+'</small></span>'+
  '<span class="vl '+(e?'in':'out')+'">'+(e?'+ ':'− ')+m(l.valor)+'<br><span class="chip '+kind+'">'+ic(l.pago?'check':(od?'warn':'clock'))+st+'</span></span></button>'}

function vInicio(){
  var bal=balanceNow(),prev=forecastEnd(),cm=monthSum(CUR.y,CUR.m,'todos'),al=alerts()[0];
  var next=S.lanc.filter(function(l){return !l.pago&&cat(l.cat)}).sort(function(a,b){return a.date<b.date?-1:a.date>b.date?1:0}).slice(0,4);
  return '<div class="hero-ext"></div><section class="card pull"><p class="lbl">Saldo atual (dinheiro que você tem agora)</p>'+
  '<p class="big num'+(bal<0?' neg':'')+'">'+m(bal)+'</p>'+(bal<0&&!S.prefs.hide?'<p class="sub">Atenção: o saldo está negativo.</p>':'')+
  '<p class="sub">Previsto para o fim de '+MESL[CUR.m-1]+': <b class="num">'+m(prev)+'</b></p>'+
  '<button class="row-link" data-act="tab" data-v="caixa">'+ic('chart')+'<span>Ver como fica o caixa nos próximos meses</span>'+ic('r')+'</button></section>'+
  (S.exemplo?'<div class="notice" style="margin-top:1rem">'+ic('info')+'<div><b>Você está vendo dados de exemplo.</b><br>Eles servem só para você conhecer o site.<button class="btn" data-act="sheet" data-v="dados">Usar os meus dados</button></div></div>':'')+
  '<div class="three" style="margin-top:1.2rem"><button class="qbtn in" data-act="add" data-v="E">'+ic('in','lg')+'<span>Entrou dinheiro</span></button>'+
  '<button class="qbtn out" data-act="add" data-v="S">'+ic('out','lg')+'<span>Saiu dinheiro</span></button>'+
  '<button class="qbtn neu" data-act="tab" data-v="extrato">'+ic('list','lg')+'<span>Ver meu extrato</span></button></div>'+
  '<h2>Neste mês — '+MESL[CUR.m-1]+'</h2><section class="card"><div class="stats">'+
  '<div class="stat in"><span class="k">'+ic('in')+'Entrou</span><span class="v num">'+m(cm.E)+'</span></div>'+
  '<div class="stat out"><span class="k">'+ic('out')+'Saiu</span><span class="v num">'+m(cm.S)+'</span></div>'+
  '<div class="stat '+(cm.op<0?'bad':'ok')+'"><span class="k">'+ic(cm.op<0?'warn':'ok')+(cm.op<0?'Faltou':'Sobrou')+'</span><span class="v num">'+m(Math.abs(cm.op))+'</span></div></div></section>'+
  '<h2>Contas e recebimentos que faltam</h2>'+(next.length?'<div class="list">'+next.map(function(l){return lrow(l,true)}).join('')+'</div>':'<div class="card empty">Nada pendente por enquanto.</div>')+
  '<h2>Atalhos</h2><div class="three">'+
  [['caixa','chart','Meu caixa'],['dicas','bulb','Dicas para você'],['cats','tag','Categorias'],['ajuda','book','Como usar'],['menu','sliders','Letra e ajustes'],['sobre','info','Sobre o protótipo']].map(function(t){
    var tab=t[0]==='caixa'||t[0]==='dicas'||t[0]==='menu';return '<button class="tile" data-act="'+(tab?'tab':'sheet')+'" data-v="'+t[0]+'"><span class="box">'+ic(t[1],'lg')+'</span>'+t[2]+'</button>'}).join('')+'</div>'+
  (al?'<h2>Dica para você</h2>'+alertCard(al)+'<button class="btn" style="margin-top:.7rem" data-act="tab" data-v="dicas">Ver todas as dicas</button>':'')}

function navMonth(label,sub,prev,next){return '<div class="stepper"><button class="iconbtn" data-act="'+prev+'" aria-label="Mês anterior">'+ic('l')+'</button><div class="mid">'+label+'<small>'+sub+'</small></div><button class="iconbtn" data-act="'+next+'" aria-label="Próximo mês">'+ic('r')+'</button></div>'}
function vExtrato(){
  var key=ui.lm.y*100+ui.lm.m,ms=monthSum(ui.lm.y,ui.lm.m,'todos');
  var rows=S.lanc.filter(function(l){return mkey(l.date)===key&&cat(l.cat)&&passes(l,ui.lf)}).sort(function(a,b){return a.date<b.date?-1:a.date>b.date?1:0});
  return '<h1>Extrato</h1><div class="stack" style="margin-top:.9rem"><button class="btn primary big" data-act="add">'+ic('plus')+'Novo lançamento</button>'+
  navMonth(MESL[ui.lm.m-1].charAt(0).toUpperCase()+MESL[ui.lm.m-1].slice(1)+' de '+ui.lm.y,ms.n+' lançamento(s) no mês','lprev','lnext')+
  '<div class="seg" role="group" aria-label="Filtrar">'+[['todos','Tudo'],['pago','Já pagos'],['aberto','Em aberto']].map(function(f){return '<button data-act="lf" data-v="'+f[0]+'" aria-pressed="'+(ui.lf===f[0])+'">'+f[1]+'</button>'}).join('')+'</div>'+
  '<section class="card"><div class="stats"><div class="stat in"><span class="k">'+ic('in')+'Entrou</span><span class="v num">'+m(ms.E)+'</span></div><div class="stat out"><span class="k">'+ic('out')+'Saiu</span><span class="v num">'+m(ms.S)+'</span></div><div class="stat '+(ms.op<0?'bad':'ok')+'"><span class="k">'+(ms.op<0?'Faltou':'Sobrou')+'</span><span class="v num">'+m(Math.abs(ms.op))+'</span></div></div></section>'+
  (rows.length?'<div class="list">'+rows.map(function(l){return lrow(l,true)}).join('')+'</div>':'<div class="card empty">Nada registrado aqui. Toque em “Novo lançamento”.</div>')+'</div>'}

function lineChart(ms,selKey){
  var W=320,H=196,L=44,R=10,T=18,B=26,vals=ms.map(function(x){return x.acc});
  var mx=Math.max.apply(null,[0].concat(vals)),mn=Math.min.apply(null,[0].concat(vals)),span=(mx-mn)||1;
  var X=function(i){return L+(W-L-R)*(i+.5)/ms.length},Y=function(v){return T+(H-T-B)*(mx-v)/span};
  var s='<svg class="chart" viewBox="0 0 '+W+' '+H+'" role="img" aria-label="Saldo mês a mês: de '+m(vals[0])+' em '+MES[ms[0].m-1]+' a '+m(vals[11])+' em '+MES[ms[11].m-1]+'">';
  if(mn<0)s+='<rect x="'+L+'" y="'+Y(0)+'" width="'+(W-L-R)+'" height="'+(H-B-Y(0))+'" fill="var(--crit-bg)"/><text x="'+(L+4)+'" y="'+(H-B-5)+'" font-size="10" style="fill:var(--crit-ink)">abaixo de zero</text>';
  [mx,0,mn].filter(function(v,i,a){return a.indexOf(v)===i}).forEach(function(v){s+='<line x1="'+L+'" x2="'+(W-R)+'" y1="'+Y(v)+'" y2="'+Y(v)+'" stroke="var(--line)" stroke-width="'+(v===0?1.5:1)+'"'+(v===0?'':' stroke-dasharray="3 3"')+'/><text x="'+(L-5)+'" y="'+(Y(v)+3.5)+'" font-size="10.5" text-anchor="end">'+(v===0?'0':kfmt(v))+'</text>'});
  var ci=ms.findIndex(function(x){return x.key===CURKEY});
  if(ci>=0)s+='<line x1="'+X(ci)+'" x2="'+X(ci)+'" y1="'+(T-4)+'" y2="'+(H-B)+'" stroke="var(--ink2)" stroke-width="1" stroke-dasharray="2 3"/><text x="'+X(ci)+'" y="'+(T-6)+'" font-size="10" text-anchor="middle" style="font-weight:700">hoje</text>';
  s+='<polyline fill="none" stroke="var(--ink)" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round" points="'+ms.map(function(x,i){return X(i)+','+Y(x.acc)}).join(' ')+'"/>';
  ms.forEach(function(x,i){
    var sel=x.key===selKey;
    s+='<circle cx="'+X(i)+'" cy="'+Y(x.acc)+'" r="'+(sel?6:3)+'" fill="'+(x.acc<0?'var(--out-fill)':'var(--ink)')+'" stroke="var(--surface)" stroke-width="2"/>';
    s+='<text x="'+X(i)+'" y="'+(H-8)+'" font-size="10" text-anchor="middle"'+(sel?' style="font-weight:700;fill:var(--ink)"':'')+'>'+MES[x.m-1]+'</text>';
    s+='<rect x="'+(X(i)-11)+'" y="'+T+'" width="22" height="'+(H-T)+'" fill="transparent" data-act="selm" data-v="'+x.key+'" style="cursor:pointer"/>'});
  return s+'</svg>'}
function brk(map,total,cls){
  var ks=Object.keys(map).sort(function(a,b){return map[b]-map[a]});
  if(!ks.length)return '<p class="muted">Nada neste mês.</p>';
  return '<div class="brk">'+ks.map(function(k){var p=total?map[k]/total*100:0;return '<div><div class="top2"><span>'+esc(cat(k).nome)+'</span><b class="num">'+m(map[k])+'</b></div><div class="bar '+cls+'" style="margin-top:.25rem"><i style="width:'+p.toFixed(1)+'%"></i></div></div>'}).join('')+'</div>'}
function vCaixa(){
  var R=window12(ui.win,ui.status),ms=R.months;
  if(!ms.some(function(x){return x.key===ui.sel}))ui.sel=ms[0].key;
  var sel=ms.find(function(x){return x.key===ui.sel}),maxv=Math.max.apply(null,ms.map(function(x){return Math.max(x.E,x.S)}).concat([1]));
  var stLbl={todos:'tudo (pago e em aberto)',pago:'só o que já foi pago',aberto:'só o que ainda está em aberto'}[ui.status];
  var w2=addMonths(ui.win.y,ui.win.m,11);
  return '<h1>Meu caixa</h1><p class="muted" style="margin-top:.3rem">Como o dinheiro entra, sai e fica, mês a mês.</p><div class="stack" style="margin-top:.9rem">'+
  '<div class="seg" role="group" aria-label="O que mostrar">'+[['todos','Tudo'],['pago','Já pago'],['aberto','Em aberto']].map(function(f){return '<button data-act="st" data-v="'+f[0]+'" aria-pressed="'+(ui.status===f[0])+'">'+f[1]+'</button>'}).join('')+'</div>'+
  navMonth(MES[ui.win.m-1]+'/'+ui.win.y+' até '+MES[w2.m-1]+'/'+w2.y,'12 meses · mostrando '+stLbl,'wprev','wnextm')+
  '<section class="card"><b>Saldo ao longo dos meses</b><p class="muted" style="font-size:.9rem;margin-bottom:.4rem">Toque em um mês para ver os detalhes.</p>'+lineChart(ms,ui.sel)+'</section>'+
  '<section class="card"><b style="font-size:1.15rem">'+monthName(sel.key).replace(/^./,function(c){return c.toUpperCase()})+'</b>'+
  '<div class="stats" style="margin-top:.7rem"><div class="stat in"><span class="k">'+ic('in')+'Entrou</span><span class="v num">'+m(sel.E)+'</span></div><div class="stat out"><span class="k">'+ic('out')+'Saiu</span><span class="v num">'+m(sel.S)+'</span></div><div class="stat '+(sel.op<0?'bad':'ok')+'"><span class="k">'+(sel.op<0?'Faltou':'Sobrou')+'</span><span class="v num">'+m(Math.abs(sel.op))+'</span></div></div>'+
  '<p style="margin-top:.8rem">Saldo no fim do mês: <b class="num" style="color:'+(sel.acc<0?'var(--crit-ink)':'inherit')+'">'+m(sel.acc)+'</b></p></section>'+
  '<section class="card"><b>De onde veio o dinheiro</b><div style="margin-top:.7rem">'+brk(sel.byE,sel.E,'in')+'</div></section>'+
  '<section class="card"><b>Para onde o dinheiro foi</b><div style="margin-top:.7rem">'+brk(sel.byS,sel.S,'out')+'</div></section>'+
  '<h2 style="margin-top:.6rem">Os 12 meses</h2><div class="legend"><span><i style="background:var(--in-fill)"></i>Entrou</span><span><i style="background:var(--out-fill)"></i>Saiu</span></div>'+
  '<div class="list">'+ms.map(function(x){var ok=x.op>=0;return '<button class="mrow" data-act="selm" data-v="'+x.key+'" aria-pressed="'+(x.key===ui.sel)+'" aria-label="'+monthName(x.key)+': entrou '+BRL.format(x.E)+', saiu '+BRL.format(x.S)+'">'+
    '<span class="mn">'+MES[x.m-1]+'<small>'+x.y+(x.key===CURKEY?' · agora':'')+'</small></span><span class="bars"><span class="bar in"><i style="width:'+(x.E/maxv*100).toFixed(1)+'%"></i></span><span class="bar out"><i style="width:'+(x.S/maxv*100).toFixed(1)+'%"></i></span></span>'+
    '<span class="res '+(ok?'ok':'bad')+'">'+(ok?'Sobrou':'Faltou')+'<br>'+m(Math.abs(x.op))+'</span></button>'}).join('')+'</div></div>'}

function vDicas(){
  var al=alerts();
  return '<h1>Dicas para você</h1><p class="muted" style="margin-top:.3rem">O assistente olha os seus lançamentos e explica, em palavras simples, o que está acontecendo e o que fazer.</p>'+
  '<div class="stack" style="margin-top:1rem">'+al.map(alertCard).join('')+'</div>'}

function vMenu(){
  var p=S.prefs;
  return '<h1>Menu</h1><div class="stack" style="margin-top:1rem">'+
  '<section class="card stack"><b>Tamanho da letra</b><div class="seg" role="group" aria-label="Tamanho da letra">'+[[1,'Normal','font-size:1rem'],[2,'Grande','font-size:1.15rem'],[3,'Gigante','font-size:1.3rem']].map(function(s){return '<button data-act="size" data-v="'+s[0]+'" aria-pressed="'+(p.size===s[0])+'" style="'+s[2]+'">'+s[1]+'</button>'}).join('')+'</div>'+
  '<b>Contraste forte</b><div class="seg" role="group" aria-label="Contraste forte">'+[[false,'Desligado'],[true,'Ligado']].map(function(s){return '<button data-act="hc" data-v="'+s[0]+'" aria-pressed="'+(p.hc===s[0])+'">'+s[1]+'</button>'}).join('')+'</div></section>'+
  '<section class="card stack"><div class="field"><label for="f-emp">Nome da empresa ou da família</label><div class="inline"><input class="input" id="f-emp" value="'+esc(S.empresa)+'" maxlength="40" autocomplete="off"><button class="btn primary" data-act="saveemp">Salvar</button></div></div>'+
  '<div class="field"><label for="f-sal">Saldo inicial</label><span class="muted" style="font-size:.9rem">Quanto dinheiro você tinha antes do primeiro lançamento.</span><div class="inline"><input class="input" id="f-sal" inputmode="decimal" value="'+String(S.saldoInicial).replace('.',',')+'" autocomplete="off"><button class="btn primary" data-act="savesal">Salvar</button></div></div></section>'+
  [['conta','user','Minha conta e avisos por e-mail'],['cats','tag','Categorias (de onde vem e para onde vai)'],['ajuda','book','Como usar, passo a passo'],['dados','repeat','Dados de exemplo ou começar do zero'],['sobre','info','Sobre este protótipo']].map(function(t){return '<button class="mi" data-act="sheet" data-v="'+t[0]+'">'+ic(t[1])+'<span>'+t[2]+'</span>'+ic('r')+'</button>'}).join('')+'</div>'}

/* ---------- folhas (telas cheias) ---------- */
function head(title,back){return '<div class="sh-head">'+(back?'<button class="btn" data-act="wback">'+ic('l')+'Voltar</button>':'<span></span>')+'<button class="btn" data-act="close">'+ic('x')+'Fechar</button></div><h1 id="sheet-title" tabindex="-1">'+title+'</h1>'}
function sAdd(){
  var w=ui.wiz,t=w.tipo==='E',h;
  var prog='<div class="prog" aria-hidden="true"><i style="width:'+(w.step/5*100)+'%"></i></div><p class="muted" style="margin:.4rem 0 .8rem">Passo '+w.step+' de 5</p>';
  if(w.step===1){h=head('O que aconteceu?',false)+prog+'<div class="stack"><button class="choice in" data-act="wtipo" data-v="E">'+ic('in','lg')+'<span>Entrou dinheiro</span></button><button class="choice out" data-act="wtipo" data-v="S">'+ic('out','lg')+'<span>Saiu dinheiro</span></button></div>'}
  else if(w.step===2){
    h=head(t?'De onde veio o dinheiro?':'Para onde foi o dinheiro?',true)+prog+'<div class="cats">'+S.cats.filter(function(c){return c.tipo===w.tipo}).map(function(c){return '<button class="cb" data-act="wcat" data-v="'+c.id+'" aria-pressed="'+(w.cat===c.id)+'">'+esc(c.nome)+'</button>'}).join('')+
    '<button class="cb" data-act="wnewcat" style="color:var(--brand)">'+ic('plus')+'&nbsp;Outra</button></div>'+
    (w.newcat?'<div class="field" style="margin-top:1rem"><label for="w-newcat">Nome da nova categoria</label><div class="inline"><input class="input" id="w-newcat" maxlength="30" autocomplete="off"><button class="btn primary" data-act="wmakecat">Criar</button></div></div>':'')}
  else if(w.step===3){h=head('Qual foi o valor?',true)+prog+'<div class="field"><label for="w-valor" class="muted" style="font-weight:400">Digite o valor em reais. Exemplo: 150 ou 150,50</label><input class="input huge num" id="w-valor" inputmode="decimal" autocomplete="off" placeholder="0,00" value="'+(w.valor?String(w.valor).replace('.',','):'')+'"><p class="preview num" id="w-prev">'+(w.valor?BRL.format(w.valor):'R$ 0,00')+'</p></div><button class="btn primary big" id="w-next3" data-act="wnext" style="margin-top:1.2rem"'+(w.valor>0?'':' disabled')+'>Continuar'+ic('r')+'</button>'}
  else if(w.step===4){
    h=head('Quando foi?',true)+prog+'<div class="stack"><div class="seg" role="group" aria-label="Quando">'+[['hoje','Hoje'],['ontem','Ontem'],['outro','Outro dia']].map(function(d){return '<button data-act="wdate" data-v="'+d[0]+'" aria-pressed="'+(w.dmode===d[0])+'">'+d[1]+'</button>'}).join('')+'</div>'+
    (w.dmode==='outro'?'<div class="field"><label for="w-date">Escolha a data (pode ser no futuro)</label><input class="input" type="date" id="w-date" value="'+w.date+'"></div>':'')+
    '<h2 style="margin:.6rem 0 0">'+(t?'Já recebeu esse dinheiro?':'Já pagou essa conta?')+'</h2><div class="two">'+
    '<button class="cb" data-act="wpago" data-v="1" aria-pressed="'+w.pago+'">'+(t?'Sim, já recebi':'Sim, já paguei')+'</button><button class="cb" data-act="wpago" data-v="0" aria-pressed="'+!w.pago+'">'+(t?'Ainda vou receber':'Ainda vou pagar')+'</button></div>'+
    '<h2 style="margin:.6rem 0 0">Isso se repete?</h2><div class="two">'+[[1,'Só desta vez'],[3,'Todo mês, por 3 meses'],[6,'Todo mês, por 6 meses'],[12,'Todo mês, por 12 meses']].map(function(r){return '<button class="cb" data-act="wrep" data-v="'+r[0]+'" aria-pressed="'+(w.rep===r[0])+'">'+r[1]+'</button>'}).join('')+'</div>'+
    '<button class="btn primary big" data-act="wnext" style="margin-top:.6rem">Continuar'+ic('r')+'</button></div>'}
  else{
    var c=cat(w.cat);
    h=head('Confira antes de salvar',true)+prog+'<section class="card sum"><div><span>Tipo</span><b>'+(t?'Entrou dinheiro':'Saiu dinheiro')+'</b></div><div><span>'+(t?'Origem':'Destino')+'</span><b>'+esc(c.nome)+'</b></div><div><span>Valor</span><b class="num">'+BRL.format(w.valor)+'</b></div><div><span>Data</span><b>'+relDate(w.date)+'</b></div><div><span>Situação</span><b>'+(w.pago?(t?'Já recebido':'Já pago'):'Em aberto')+'</b></div>'+(w.rep>1?'<div><span>Repete</span><b>Todo mês, '+w.rep+' vezes</b></div>':'')+'</section>'+
    (w.rep>1?'<p class="muted" style="margin-top:.6rem">Os '+(w.rep-1)+' lançamentos dos meses seguintes ficam “em aberto”.</p>':'')+
    '<div class="field" style="margin-top:1rem"><label for="w-obs">Quer anotar algo? (não precisa)</label><input class="input" id="w-obs" maxlength="60" autocomplete="off" value="'+esc(w.obs||'')+'"></div><button class="btn primary big" data-act="wsave" style="margin-top:1rem">'+ic('check')+'Salvar lançamento</button>'}
  return h}
function sLanc(){
  var l=S.lanc.find(function(x){return x.id===ui.lancId});if(!l)return head('Lançamento',false);
  var c=cat(l.cat)||{nome:'Sem categoria',tipo:'S'},e=c.tipo==='E';
  var series=l.rec?S.lanc.filter(function(x){return x.rec===l.rec&&x.date>l.date}).length:0;
  var h=head('Detalhes do lançamento',false)+'<section class="card sum"><div><span>Tipo</span><b>'+(e?'Entrou dinheiro':'Saiu dinheiro')+'</b></div><div><span>'+(e?'Origem':'Destino')+'</span><b>'+esc(c.nome)+'</b></div><div><span>Valor</span><b class="num">'+BRL.format(l.valor)+'</b></div><div><span>Data</span><b>'+relDate(l.date)+'</b></div><div><span>Situação</span><b>'+(l.pago?(e?'Já recebido':'Já pago'):'Em aberto')+'</b></div>'+(l.obs?'<div><span>Anotação</span><b>'+esc(l.obs)+'</b></div>':'')+'</section><div class="stack" style="margin-top:1rem">';
  h+=l.pago?'<button class="btn big" data-act="ltoggle">Voltar para “em aberto”</button>':'<button class="btn primary big" data-act="ltoggle">'+ic('check')+(e?'Marcar como recebido':'Marcar como pago')+'</button>';
  if(ui.conf==='del')h+='<div class="notice" style="background:var(--crit-bg);color:var(--crit-ink)">'+ic('warn')+'<div><b>Excluir este lançamento?</b><br>Não dá para desfazer.</div></div><div class="two"><button class="btn danger" data-act="ldel1">Sim, excluir</button><button class="btn" data-act="lcancel">Não</button></div>';
  else{h+='<button class="btn danger" data-act="ldel">'+ic('trash')+'Excluir</button>';if(series)h+='<button class="btn danger" data-act="ldelser">'+ic('trash')+'Excluir este e os '+series+' seguintes</button>'}
  return h+'</div>'}
function sCats(){
  var used=function(id){return S.lanc.some(function(l){return l.cat===id})};
  var list=function(t){return '<div class="list">'+S.cats.filter(function(c){return c.tipo===t}).map(function(c){return '<div class="lrow"><span class="tx"><b>'+esc(c.nome)+'</b>'+(used(c.id)?'<small>em uso, não dá para apagar</small>':'')+'</span>'+(used(c.id)?'':'<button class="iconbtn" data-act="delcat" data-id="'+c.id+'" aria-label="Apagar '+esc(c.nome)+'" style="color:var(--crit-ink)">'+ic('trash')+'</button>')+'</div>'}).join('')+'</div>'};
  return head('Categorias',false)+'<p class="muted">Aqui você escolhe de onde vem e para onde vai o seu dinheiro. Pode criar quantas quiser.</p>'+
  '<div class="field" style="margin-top:1rem"><label for="c-new">Nova categoria</label><input class="input" id="c-new" maxlength="30" autocomplete="off"></div><div class="two" style="margin-top:.6rem"><button class="btn" data-act="addcat" data-v="E" style="color:var(--in-ink)">'+ic('in')+'Entrou</button><button class="btn" data-act="addcat" data-v="S" style="color:var(--out-ink)">'+ic('out')+'Saiu</button></div>'+
  '<h2>Entrou dinheiro</h2>'+list('E')+'<h2>Saiu dinheiro</h2>'+list('S')}
function sAjuda(){
  var st=[['Veja o seu saldo','Na tela inicial aparece o dinheiro que você tem agora e o que está previsto para o fim do mês.'],['Registre o que acontece','Toque em “Entrou dinheiro” ou “Saiu dinheiro”. São 5 passos curtos, sempre com um assunto por tela.'],['Marque o que já foi pago','No Extrato, toque no lançamento e use o botão grande para marcar como pago ou recebido.'],['Olhe o seu caixa','Em “Meu caixa” você vê os próximos 12 meses e descobre se vai sobrar ou faltar dinheiro.'],['Leia as dicas','O assistente avisa o que merece atenção e sugere o que fazer.'],['Atualize toda semana','Cinco minutos por semana já deixam o caixa em dia.']];
  return head('Como usar',false)+'<div class="stack" style="margin-top:1rem">'+st.map(function(s,i){return '<section class="card"><b>'+(i+1)+'. '+s[0]+'</b><p style="margin-top:.3rem">'+s[1]+'</p></section>'}).join('')+'</div>'}
function sSobre(){
  var ok=['Conta com e-mail e senha, e-mail confirmado e dados separados por pessoa','Avisos por e-mail: contas a vencer, atrasos e caixa em risco','Categorias sem limite (a planilha tem 46 vagas fixas)','Lançamentos sem limite (a planilha para em cerca de 537 linhas)','Repetição automática de contas mensais','Saldo que continua certo ao mudar o período','Dicas automáticas em linguagem simples, vindas do Tutorial da planilha','Letra grande, contraste forte e botões grandes','Funciona no celular, com um assunto por tela'];
  var no=['Segunda etapa de segurança no login (código no celular)','Cadastro de clientes e fornecedores','Contas bancárias e carteiras separadas','Data de vencimento separada da data de pagamento','Importar extrato do banco','Lembretes por WhatsApp','Relatórios em PDF e Excel','Textos finais de termos de uso e privacidade (LGPD)']
  ;return head('Sobre este protótipo',false)+'<p class="muted">Primeira versão para você sentir como o site pode ser. Foi montada em cima da lógica da planilha de fluxo de caixa.</p>'+
  '<h2>O que já está resolvido</h2><section class="card"><ul class="plain">'+ok.map(function(x){return '<li>'+x+'</li>'}).join('')+'</ul></section>'+
  '<h2>O que falta construir</h2><section class="card"><ul class="plain">'+no.map(function(x){return '<li>'+x+'</li>'}).join('')+'</ul></section>'}
function sDados(){
  var h=head('Seus dados',false)+'<p class="muted">Os seus dados ficam salvos na sua conta e só você consegue ver.</p><div class="stack" style="margin-top:1rem">';
  if(ui.conf==='reset')return h+'<div class="notice" style="background:var(--crit-bg);color:var(--crit-ink)">'+ic('warn')+'<div><b>Apagar tudo e começar do zero?</b><br>Os lançamentos atuais serão apagados.</div></div><div class="two"><button class="btn danger" data-act="doreset">Sim, apagar</button><button class="btn" data-act="lcancel">Não</button></div></div>';
  return h+'<button class="btn primary big" data-act="reset">Começar do zero com os meus dados</button><button class="btn big" data-act="example">Voltar aos dados de exemplo</button></div>'}
function renderSheet(){
  var k=ui.sheet,el=$('#sheet'),f={add:sAdd,lanc:sLanc,cats:sCats,ajuda:sAjuda,sobre:sSobre,dados:sDados,conta:sConta}[k];
  if(!f){el.hidden=true;document.body.style.overflow='';return}
  $('#sheet-in').innerHTML=f();el.hidden=false;document.body.style.overflow='hidden'}
function focusSheet(sel){var t=$(sel||'#sheet-title');if(t)try{t.focus({preventScroll:true})}catch(e){};$('#sheet').scrollTop=0}
function openSheet(k,id){ui.sheet=k;ui.conf=null;if(k==='conta')ui.acc={};if(id)ui.lancId=id;renderSheet();focusSheet()}
function closeSheet(){ui.sheet=null;ui.wiz=null;ui.conf=null;renderSheet();render(true)}


/* ---------- telas de entrada (login, criar conta, recuperar senha) ---------- */
function fieldEmail(v,auto){return '<div class="field"><label for="a-email">Seu e-mail</label><input class="input" id="a-email" name="email" type="email" inputmode="email" autocomplete="'+auto+'" autocapitalize="none" spellcheck="false" maxlength="254" value="'+esc(v||'')+'"></div>'}
function fieldPw(id,name,label,auto,hint){return '<div class="field"><label for="'+id+'">'+label+'</label>'+(hint?'<span class="muted" style="font-size:.9rem">'+hint+'</span>':'')+'<div class="pwrow"><input class="input" id="'+id+'" name="'+name+'" type="password" autocomplete="'+auto+'" maxlength="128"><button type="button" class="btn" data-act="showpw" data-v="'+id+'" aria-pressed="false">Mostrar</button></div></div>'}
function authErr(a){return '<div class="err" id="a-err" role="alert"'+(a.err?'':' hidden')+'>'+esc(a.err||'')+'</div><div id="a-extra"></div>'}
function vAuth(){
  var a=ui.auth,s=a.screen,h='';
  var notice=a.msg?'<div class="notice" style="margin-bottom:1rem">'+ic('ok')+'<div>'+esc(a.msg)+'</div></div>':'';
  var size='<section class="card stack" style="margin-top:1.4rem"><b>Tamanho da letra</b><div class="seg" role="group" aria-label="Tamanho da letra">'+[[1,'Normal','font-size:1rem'],[2,'Grande','font-size:1.15rem'],[3,'Gigante','font-size:1.3rem']].map(function(x){return '<button type="button" data-act="size" data-v="'+x[0]+'" aria-pressed="'+(P().size===x[0])+'" style="'+x[2]+'">'+x[1]+'</button>'}).join('')+'</div></section>';
  if(s==='loading')return '<div class="card empty" style="margin-top:1rem">Abrindo…</div>';
  if(s==='verifying')return '<div class="card empty" style="margin-top:1rem">Confirmando o seu e-mail…</div>';
  if(s==='login'){
    h='<h1 id="a-h" tabindex="-1">Entrar</h1><p class="muted" style="margin:.3rem 0 1rem">Use o e-mail e a senha que você criou.</p>'+notice+
    '<form data-form="login" class="card stack" novalidate>'+fieldEmail(a.email,'username')+fieldPw('a-senha','senha','Sua senha','current-password')+authErr(a)+'<button type="submit" class="btn primary big">Entrar</button></form>'+
    '<div class="stack" style="margin-top:1rem"><button type="button" class="linkbtn" data-act="auth" data-v="forgot">Esqueci minha senha</button><button type="button" class="btn big" data-act="auth" data-v="signup">'+ic('user')+'Criar minha conta</button></div>'+size;
  }else if(s==='signup'){
    h='<h1 id="a-h" tabindex="-1">Criar minha conta</h1><p class="muted" style="margin:.3rem 0 1rem">Você escolhe o e-mail e a senha. Vamos enviar um e-mail para confirmar que ele é seu.</p>'+
    '<form data-form="signup" class="card stack" novalidate>'+fieldEmail(a.email,'username')+fieldPw('a-senha','senha','Crie uma senha','new-password','Pelo menos 10 caracteres. Dica: use uma frase fácil de lembrar, como “meu gato dorme no sofa”. Pode usar espaços.')+
    '<label class="check"><input type="checkbox" name="aceite" id="a-aceite"><span>Li e aceito os termos de uso e a política de privacidade. Sei que os avisos do site serão enviados para o meu e-mail.</span></label>'+
    authErr(a)+'<button type="submit" class="btn primary big">Criar conta</button></form>'+
    '<div class="stack" style="margin-top:1rem"><button type="button" class="btn big" data-act="auth" data-v="login">Já tenho conta. Entrar</button></div>'+size;
  }else if(s==='forgot'){
    h='<h1 id="a-h" tabindex="-1">Esqueci minha senha</h1><p class="muted" style="margin:.3rem 0 1rem">Escreva o seu e-mail. Enviaremos um link para você criar uma nova senha.</p>'+
    '<form data-form="forgot" class="card stack" novalidate>'+fieldEmail(a.email,'username')+authErr(a)+'<button type="submit" class="btn primary big">Enviar o link</button></form>'+
    '<div class="stack" style="margin-top:1rem"><button type="button" class="btn big" data-act="auth" data-v="login">Voltar para entrar</button></div>'+size;
  }else if(s==='reset'){
    h='<h1 id="a-h" tabindex="-1">Criar uma nova senha</h1><p class="muted" style="margin:.3rem 0 1rem">Escolha uma senha nova. Depois é só entrar.</p>'+
    '<form data-form="reset" class="card stack" novalidate>'+fieldPw('a-senha','senha','Nova senha','new-password','Pelo menos 10 caracteres. Uma frase fácil de lembrar é uma boa senha.')+authErr(a)+'<button type="submit" class="btn primary big">Salvar nova senha</button></form>'+size;
  }else if(s==='sent'){
    h='<div class="stack" style="margin-top:1rem;justify-items:start"><span class="bigmail">'+ic('mail')+'</span><h1 id="a-h" tabindex="-1">Veja o seu e-mail</h1><p>'+esc(a.msg||'')+'</p>'+
    '<section class="card"><b>Não chegou?</b><ul class="plain"><li>Pode demorar alguns minutos.</li><li>Olhe também a caixa de spam ou lixo eletrônico.</li><li>Confira se o e-mail está certo: <b style="overflow-wrap:anywhere">'+esc(a.email||'')+'</b></li></ul></section>'+
    (a.kind==='signup'?'<button type="button" class="btn big" data-act="resend">Enviar o e-mail de novo</button>':'')+
    '<button type="button" class="btn big" data-act="auth" data-v="login">Voltar para entrar</button></div>';
  }
  return h;
}
function setBusy(f,on){var b=f.querySelector('button[type=submit]');if(!b)return;if(!b.dataset.l)b.dataset.l=b.textContent;b.disabled=on;b.textContent=on?'Aguarde…':b.dataset.l}
function showErr(msg){var e=$('#a-err');if(e){e.textContent=msg||'';e.hidden=!msg}}
function authFocus(){var t=$('#a-h');if(t)try{t.focus({preventScroll:true})}catch(e){}}
var formHandlers={
  login:function(f){
    var email=f.elements.email.value.trim(),senha=f.elements.senha.value;
    if(!email||!senha){showErr('Preencha o e-mail e a senha.');return}
    setBusy(f,true);showErr('');
    api('POST','/api/auth/entrar',{email:email,senha:senha}).then(function(r){
      if(r.ok){enter(r.data.email,true);return}
      setBusy(f,false);ui.auth.email=email;showErr(r.data.message||'Não deu certo. Tente de novo.');
      var x=$('#a-extra');if(x&&r.data.error==='email_nao_confirmado')x.innerHTML='<button type="button" class="btn" data-act="resend" style="margin-top:.7rem">Enviar o e-mail de confirmação de novo</button>';
    });
  },
  signup:function(f){
    var email=f.elements.email.value.trim(),senha=f.elements.senha.value;
    if(!/^\S+@\S+\.\S{2,}$/.test(email)){showErr('Confira o e-mail: ele parece estar incompleto.');return}
    if(senha.length<10){showErr('A senha precisa ter pelo menos 10 caracteres. Dica: use uma frase fácil de lembrar.');return}
    if(!f.elements.aceite.checked){showErr('Para criar a conta, marque que você leu e aceita os termos.');return}
    setBusy(f,true);showErr('');
    api('POST','/api/auth/criar-conta',{email:email,senha:senha,consentimento:true}).then(function(r){
      if(r.ok){ui.auth={screen:'sent',kind:'signup',email:email,msg:r.data.message};render();authFocus();return}
      setBusy(f,false);ui.auth.email=email;showErr(r.data.message||'Não deu certo. Tente de novo.');
    });
  },
  forgot:function(f){
    var email=f.elements.email.value.trim();
    if(!/^\S+@\S+\.\S{2,}$/.test(email)){showErr('Confira o e-mail: ele parece estar incompleto.');return}
    setBusy(f,true);showErr('');
    api('POST','/api/auth/esqueci',{email:email}).then(function(r){
      if(r.ok){ui.auth={screen:'sent',kind:'reset',email:email,msg:r.data.message};render();authFocus();return}
      setBusy(f,false);showErr(r.data.message||'Não deu certo. Tente de novo.');
    });
  },
  reset:function(f){
    var senha=f.elements.senha.value;
    if(senha.length<10){showErr('A senha precisa ter pelo menos 10 caracteres.');return}
    setBusy(f,true);showErr('');
    api('POST','/api/auth/redefinir',{token:ui.auth.token,senha:senha}).then(function(r){
      if(r.ok){ui.auth={screen:'login',msg:r.data.message};render();authFocus();return}
      setBusy(f,false);showErr(r.data.message||'Não deu certo. Tente de novo.');
    });
  },
  senha:function(f){
    var atual=f.elements.atual.value,nova=f.elements.nova.value;
    if(!atual||!nova){ui.acc={err:'Preencha a senha atual e a nova.'};renderSheet();return}
    setBusy(f,true);
    api('POST','/api/eu/senha',{atual:atual,nova:nova}).then(function(r){ui.acc=r.ok?{msg:r.data.message}:{err:r.data.message||'Não deu certo.'};renderSheet();focusSheet()});
  },
  apagar:function(f){
    var senha=f.elements.senha.value;if(!senha){ui.acc={err:'Escreva a sua senha para confirmar.',conf:'del'};renderSheet();return}
    setBusy(f,true);
    api('DELETE','/api/eu',{senha:senha}).then(function(r){
      if(r.ok)sessionEnded('Sua conta e os seus dados foram apagados.',true);
      else{ui.acc={err:r.data.message||'Não deu certo.',conf:'del'};renderSheet();focusSheet()}
    });
  }
};
document.addEventListener('submit',function(e){var f=e.target,k=f&&f.dataset&&f.dataset.form;if(!k)return;e.preventDefault();if(formHandlers[k])formHandlers[k](f)});

function sConta(){
  var u=ui.user||{},a=ui.acc||{};
  var h=head('Minha conta',false)+(a.msg?'<div class="notice" style="margin-bottom:1rem">'+ic('ok')+'<div>'+esc(a.msg)+'</div></div>':'')+(a.err?'<div class="err" role="alert" style="margin-bottom:1rem">'+esc(a.err)+'</div>':'');
  h+='<div class="stack"><section class="card"><p class="lbl">E-mail de acesso</p><p style="font-weight:700;overflow-wrap:anywhere">'+esc(u.email||'')+'</p><span class="chip good" style="margin-top:.4rem">'+ic('check')+'Confirmado</span></section>';
  h+='<section class="card stack"><b>Avisos por e-mail</b><p class="muted">Enviamos no máximo 1 e-mail por dia, e só quando há algo importante: contas que vencem em até 3 dias, contas e recebimentos atrasados e risco de o caixa ficar negativo.</p><div class="seg" role="group" aria-label="Avisos por e-mail">'+
    [[true,'Ligados'],[false,'Desligados']].map(function(x){return '<button type="button" data-act="avisos" data-v="'+x[0]+'" aria-pressed="'+(!!u.avisos===x[0])+'">'+x[1]+'</button>'}).join('')+'</div></section>';
  h+='<form data-form="senha" class="card stack" novalidate><b>Trocar a senha</b>'+fieldPw('c-atual','atual','Senha atual','current-password')+fieldPw('c-nova','nova','Senha nova','new-password','Pelo menos 10 caracteres.')+'<button type="submit" class="btn primary">'+ic('lock')+'Trocar senha</button><span class="muted" style="font-size:.9rem">Ao trocar, os outros aparelhos são desconectados e você recebe um e-mail de aviso.</span></form>';
  h+='<button type="button" class="btn" data-act="exportar">'+ic('down')+'Baixar uma cópia dos meus dados</button>';
  h+='<button type="button" class="btn" data-act="sair">Sair deste aparelho</button>';
  if(a.conf==='del')h+='<form data-form="apagar" class="card stack" novalidate style="border-color:var(--crit-ink)"><b style="color:var(--crit-ink)">Apagar minha conta?</b><p>Isso apaga a conta e todos os seus lançamentos. Não dá para desfazer.</p>'+fieldPw('c-del','senha','Escreva a sua senha para confirmar','current-password')+'<button type="submit" class="btn danger">'+ic('trash')+'Sim, apagar tudo</button><button type="button" class="btn" data-act="acccancel">Não, voltar</button></form>';
  else h+='<button type="button" class="btn danger" data-act="apagarpedir">'+ic('trash')+'Apagar minha conta</button>';
  return h+'</div>';
}
function boot(){
  var q=new URLSearchParams(location.search),vt=q.get('verificar'),rt=q.get('redefinir'),eq=q.get('esqueci');
  if(vt||rt||eq){try{history.replaceState(null,'',location.pathname+location.hash)}catch(e){}}
  var pre=Promise.resolve();
  if(vt){
    ui.auth={screen:'verifying'};render();
    pre=api('POST','/api/auth/confirmar-email',{token:vt}).then(function(r){ui.auth=r.ok?{screen:'login',msg:(r.data.message||'E-mail confirmado!')+' Entre com o e-mail e a senha que você criou.'}:{screen:'login',err:r.data.message||'Não deu certo. Tente de novo.'}});
  }else if(rt){ui.auth={screen:'reset',token:rt}}
  else if(eq){ui.auth={screen:'forgot'}}
  else ui.auth={screen:'loading'};
  render();
  return pre.then(function(){return api('GET','/api/eu')}).then(function(me){
    if(me.ok&&!rt){return enter(me.data.email,me.data.avisos)}
    if(ui.auth.screen==='loading')ui.auth={screen:'login'};
    render();authFocus();
  });
}
document.addEventListener('visibilitychange',function(){if(document.visibilityState==='hidden')flush()});

function render(keepScroll){
  document.documentElement.dataset.size=String(P().size);
  if(P().hc)document.documentElement.dataset.hc='1';else delete document.documentElement.dataset.hc;
  renderTop();renderTabs();
  if(!ui.user){var y0=window.scrollY;$('#view').innerHTML=vAuth();if(keepScroll)window.scrollTo(0,y0);return}
  var f={inicio:vInicio,extrato:vExtrato,caixa:vCaixa,dicas:vDicas,menu:vMenu}[ui.tab];
  var y=window.scrollY;$('#view').innerHTML=f();if(keepScroll)window.scrollTo(0,y)}
function go(tab){ui.tab=tab;try{location.hash=tab}catch(e){}render();window.scrollTo(0,0)}

/* ---------- ações ---------- */
function openAdd(tipo){ui.wiz={step:tipo?2:1,tipo:tipo||null,cat:null,valor:0,dmode:'hoje',date:TODAY,pago:true,rep:1,newcat:false,obs:''};openSheet('add')}
function saveWiz(){
  var w=ui.wiz,b=parseD(w.date),rid=w.rep>1?uid():undefined;
  for(var i=0;i<w.rep;i++){var mm=addMonths(b.y,b.m,i),dim=new Date(mm.y,mm.m,0).getDate(),d=mm.y+'-'+pad(mm.m)+'-'+pad(Math.min(b.d,dim));
    var o={id:uid(),date:d,cat:w.cat,valor:w.valor,pago:i===0?w.pago:false,obs:w.obs||''};if(rid)o.rec=rid;S.lanc.push(o)}
  ui.lm={y:b.y,m:b.m};save();var n=w.rep;closeSheet();toast(n>1?n+' lançamentos salvos':'Lançamento salvo')}
function act(a,b){
  var v=b.dataset.v,w=ui.wiz;
  switch(a){
    case 'tab':go(v);break;
    case 'hide':S.prefs.hide=!S.prefs.hide;save();render(true);break;
    case 'add':openAdd(v);break;
    case 'sheet':openSheet(v);break;
    case 'close':closeSheet();break;
    case 'wtipo':w.tipo=v;w.cat=null;w.step=2;openSheet('add');break;
    case 'wcat':w.cat=v;w.step=3;renderSheet();focusSheet('#w-valor');break;
    case 'wnewcat':w.newcat=!w.newcat;renderSheet();if(w.newcat)focusSheet('#w-newcat');break;
    case 'wmakecat':{var nm=($('#w-newcat').value||'').trim();if(!nm){toast('Escreva o nome da categoria');break}
      var id='c'+uid();S.cats.push({id:id,nome:nm,tipo:w.tipo});save();w.cat=id;w.newcat=false;w.step=3;renderSheet();focusSheet('#w-valor');break}
    case 'wnext':if(w.step===3&&!(w.valor>0))break;w.step++;renderSheet();focusSheet();break;
    case 'wback':if(w.step<=1){closeSheet();break}w.step--;if(w.step===1&&w.tipo&&b.dataset.v===undefined){}renderSheet();focusSheet();break;
    case 'wdate':w.dmode=v;if(v==='hoje')w.date=TODAY;else if(v==='ontem'){var y=new Date(NOW);y.setDate(y.getDate()-1);w.date=ymd(y)}w.pago=w.date<=TODAY;renderSheet();break;
    case 'wpago':w.pago=v==='1';renderSheet();break;
    case 'wrep':w.rep=Number(v);renderSheet();break;
    case 'wsave':saveWiz();break;
    case 'lanc':openSheet('lanc',b.dataset.id);break;
    case 'ltoggle':{var l=S.lanc.find(function(x){return x.id===ui.lancId});if(l){l.pago=!l.pago;save();var e=cat(l.cat)&&cat(l.cat).tipo==='E';closeSheet();toast(l.pago?(e?'Marcado como recebido':'Marcado como pago'):'Voltou para em aberto')}break}
    case 'ldel':ui.conf='del';renderSheet();break;
    case 'lcancel':ui.conf=null;renderSheet();break;
    case 'ldel1':S.lanc=S.lanc.filter(function(x){return x.id!==ui.lancId});save();closeSheet();toast('Lançamento excluído');break;
    case 'ldelser':{var l2=S.lanc.find(function(x){return x.id===ui.lancId});if(l2&&l2.rec){S.lanc=S.lanc.filter(function(x){return !(x.rec===l2.rec&&x.date>=l2.date)})}save();closeSheet();toast('Lançamentos excluídos');break}
    case 'lprev':{var p=addMonths(ui.lm.y,ui.lm.m,-1);ui.lm=p;render(true);break}
    case 'lnext':{var q=addMonths(ui.lm.y,ui.lm.m,1);ui.lm=q;render(true);break}
    case 'lf':ui.lf=v;render(true);break;
    case 'st':ui.status=v;render(true);break;
    case 'wprev':ui.win=addMonths(ui.win.y,ui.win.m,-1);render(true);break;
    case 'wnextm':ui.win=addMonths(ui.win.y,ui.win.m,1);render(true);break;
    case 'selm':ui.sel=Number(v);render(true);break;
    case 'size':P().size=Number(v);save();render(true);break;
    case 'hc':P().hc=v==='true';save();render(true);break;
    case 'saveemp':{var n=($('#f-emp').value||'').trim();if(n){S.empresa=n;save();render(true);toast('Nome salvo')}break}
    case 'savesal':S.saldoInicial=round2(parseMoney($('#f-sal').value));save();render(true);toast('Saldo inicial salvo');break;
    case 'addcat':{var nc=($('#c-new').value||'').trim();if(!nc){toast('Escreva o nome da categoria');break}S.cats.push({id:'c'+uid(),nome:nc,tipo:v});save();renderSheet();focusSheet('#c-new');toast('Categoria criada');break}
    case 'delcat':S.cats=S.cats.filter(function(c){return c.id!==b.dataset.id});save();renderSheet();break;
    case 'reset':ui.conf='reset';renderSheet();break;
    case 'doreset':{var pr=S.prefs;S=fresh(false);S.prefs=pr;save();closeSheet();go('inicio');toast('Tudo limpo. Pode começar!');break}
    case 'auth':ui.auth={screen:v,email:ui.auth.email||''};render();window.scrollTo(0,0);authFocus();break;
    case 'showpw':{var inp=document.getElementById(v);if(inp){var show=inp.type==='password';inp.type=show?'text':'password';b.textContent=show?'Esconder':'Mostrar';b.setAttribute('aria-pressed',String(show))}break}
    case 'resend':{var em=ui.auth.email;if(!em){toast('Escreva o seu e-mail primeiro');break}api('POST','/api/auth/reenviar',{email:em}).then(function(r){toast(r.ok?'Pedido enviado. Veja o seu e-mail.':(r.data.message||'Não deu certo.'))});break}
    case 'avisos':api('PUT','/api/eu/avisos',{ligado:v==='true'}).then(function(r){if(r.ok){ui.user.avisos=r.data.avisos;ui.acc={msg:r.data.avisos?'Avisos por e-mail ligados.':'Avisos por e-mail desligados.'}}else ui.acc={err:r.data.message||'Não deu certo.'};renderSheet();focusSheet()});break;
    case 'exportar':api('GET','/api/exportar').then(function(r){if(!r.ok){ui.acc={err:r.data.message||'Não deu certo.'};renderSheet();return}var bl=new Blob([JSON.stringify(r.data,null,2)],{type:'application/json'});var al=document.createElement('a');al.href=URL.createObjectURL(bl);al.download='fluxo-facil-meus-dados.json';document.body.appendChild(al);al.click();al.remove();setTimeout(function(){URL.revokeObjectURL(al.href)},1000);toast('Cópia baixada')});break;
    case 'sair':flush().then(function(){return api('POST','/api/auth/sair',{})}).then(function(){sessionEnded('Você saiu da sua conta.',true)});break;
    case 'apagarpedir':ui.acc={conf:'del'};renderSheet();focusSheet();break;
    case 'acccancel':ui.acc={};renderSheet();focusSheet();break;
    case 'example':{var pr2=S.prefs;S=fresh(true);S.prefs=pr2;save();closeSheet();go('inicio');toast('Dados de exemplo carregados');break}
  }}
document.addEventListener('click',function(e){
  var b=e.target.closest('[data-act]');if(!b)return;
  act(b.dataset.act,b)});
document.addEventListener('input',function(e){
  var t=e.target;
  if(t.id==='w-valor'){ui.wiz.valor=Math.max(0,round2(parseMoney(t.value)));$('#w-prev').textContent=ui.wiz.valor?BRL.format(ui.wiz.valor):'R$ 0,00';var nb=$('#w-next3');if(nb)nb.disabled=!(ui.wiz.valor>0)}
  else if(t.id==='w-obs')ui.wiz.obs=t.value;
  else if(t.id==='w-date'&&t.value){ui.wiz.date=t.value;ui.wiz.pago=t.value<=TODAY}});
document.addEventListener('keydown',function(e){
  if(e.key==='Escape'&&ui.sheet)closeSheet();
  if(e.key==='Enter'&&ui.sheet){var id=e.target.id;if(id==='w-newcat')act('wmakecat',e.target);else if(id==='c-new')act('addcat',{dataset:{v:'S'}});else if(id==='w-valor'&&ui.wiz.valor>0)act('wnext',e.target)}});

try{var h=(location.hash||'').replace('#','');if(['inicio','extrato','caixa','dicas','menu'].indexOf(h)>=0)ui.tab=h}catch(e){}
boot();
})();
